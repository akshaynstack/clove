import './style.css'
import Experience from './Experience/Experience.js'

window.experience = new Experience({
    targetElement: document.querySelector('.experience')
})

